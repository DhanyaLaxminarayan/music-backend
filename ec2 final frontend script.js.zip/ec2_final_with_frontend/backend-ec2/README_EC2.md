# EC2 Backend Final Package

This package contains the EC2 backend files plus the latest frontend `script.js`.

## Final EC2 backend configuration

- EC2 public backend URL: `http://100.30.49.178`
- Public port: `80`
- Docker internal app port: `5000`
- Docker port mapping: `-p 80:5000`
- Login table: `login`
- Music table: `music-final`
- Subscriptions table: `subscriptions`
- S3 image bucket: `music-a2-images-307302876893-final`
- GSI: `YearArtistIndex`
- LSI: `album-index`

## Why internal port 5000 is acceptable

The assignment requires the web application to run on standard HTTP(S) ports 80 or 443 for external access. The EC2 backend is publicly exposed on port 80. Port 5000 is only used inside the Docker container and is mapped to port 80 externally, so users and markers access the app through `http://100.30.49.178` without `:5000`.

## Rebuild and run on EC2

```bash
cd ~/music-backend-final

docker build --no-cache -t music-backend-final .

docker rm -f music-backend-final || true

docker run -d --name music-backend-final --restart unless-stopped -p 80:5000   -e AWS_REGION=us-east-1   -e LOGIN_TABLE=login   -e MUSIC_TABLE=music-final   -e SUBSCRIPTIONS_TABLE=subscriptions   -e S3_BUCKET=music-a2-images-307302876893-final   -e FRONTEND_ORIGIN="*"   music-backend-final
```

## Test commands

```bash
curl http://100.30.49.178/health
curl "http://100.30.49.178/getMusic?artist=Taylor%20Swift&album=Fearless"
curl "http://100.30.49.178/getMusic?artist=Jimmy%20Buffett&year=1974"
```
